jQuery(document).ready(function($){
      AOS.init({
            once: true,
            offset:300,
      });
});